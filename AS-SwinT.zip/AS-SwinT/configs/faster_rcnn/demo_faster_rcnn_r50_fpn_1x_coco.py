_base_ = './faster_rcnn_r50_fpn_1x_coco.py'

model = dict(
    roi_head=dict(
        bbox_head=dict(num_classes=3)))

dataset_type = 'COCODataset'
classes = ('flower', 'vice flower')
data = dict(
    samples_per_gpu=6,  # batch size
    workers_per_gpu=6,  # num_workers
    train=dict(
        img_prefix='D:/mmdetection-master/data/coco/',
        classes=classes,
        ann_file='D:/mmdetection-master/data/coco/annotations/instances_train2017.json'),
    val=dict(
        img_prefix='D:/mmdetection-master/data/coco/',
        classes=classes,
        ann_file='D:/mmdetection-master/data/coco/annotations/instances_val2017.json'),
    test=dict(
        img_prefix='D:/mmdetection-master/data/coco/',
        classes=classes,
        ann_file='D:/mmdetection-master/data/coco/annotations/instances_test2017.json'))

load_from = 'D:/mmdetection-master/faster_rcnn_r50_fpn_1x_coco_20200130-047c8118.pth'
# runner = dict(_delete_=True, type='IterBasedRunner', max_iters=90000)
# runner = dict(type='EpochBasedRunner', max_epochs=20)